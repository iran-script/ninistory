# NiniStory Visual Assets — PREVIEW ONLY

These JPGs are crops from an AI-generated composite concept image; they are NOT original high-resolution photography, not production-ready individual SKU photographs, and may include typography/icon/edge artifacts.

Use for local visual prototype only. Do not publish to a live storefront or assert that the clothing shown matches an actual stocked SKU. Replace with original high-resolution licensed photography and clean banner exports before production.

Font files are intentionally NOT bundled. Install Vazirmatn from the OFFICIAL source https://github.com/rastikerdar/vazirmatn (SIL OFL 1.1), with license notice preserved, preferably via npm install vazirmatn and local font loading. Never use images of real customers' children without explicit permission.

Copy the `images` directory into `public/assets/ninistory-preview` (or the site's configured local assets path). Reference images from PHP/Blade with asset('assets/ninistory-preview/images/...'). Configure a local-only preview mode; do not replace real product images or invent stock/prices.
